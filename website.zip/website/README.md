# My website and data analysis portfolio

This is the Github respository for Zhang Yi's *the Informational Technologies in Business class* course portfolio for Fall 2024. My website can be found [here](https://zhangyi-96.github.io/)! 